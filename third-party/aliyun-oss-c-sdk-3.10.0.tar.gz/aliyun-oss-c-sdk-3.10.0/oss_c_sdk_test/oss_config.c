#include "oss_config.h"

char* TEST_OSS_ENDPOINT = NULL;
char* TEST_ACCESS_KEY_ID = NULL;
char* TEST_ACCESS_KEY_SECRET = NULL;
char* TEST_BUCKET_NAME = NULL;
char* TEST_CALLBACK_URL = NULL;
